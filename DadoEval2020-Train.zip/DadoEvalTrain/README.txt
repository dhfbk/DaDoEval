This folder contains the training data for the DaDoEval 2020 shared task on dating Alcide De Gasperi’s documents (https://dhfbk.github.io/DaDoEval/).

1) Train/ folder:

— CoarseTask/: list of documents for training, one folder per class.
Five classes are included:
Class 1 (Habsburg years), documents issued between 1901 and 1918
Class 2 (Beginning of political activity), documents issued between 1919 and 1926
Class 3 (Internal exile), documents issued between 1927 and 1942
Class 4 (From fascism to the Italian Republic), documents issued between 1943 and 1947
Class 5 (Building the Italian Republic), documents issued between 1948 and 1954
The goal of this task is to automatically assign unseen documents to one of the five classes.


- FineTask/: list of documents for training, one folder per 5-year time period.
The goal of this task is to automatically assign unseen documents to one of the eleven predefined time periods.

- YearBasedTask/: list of documents for training, one folder per year
The goal of this task is to automatically assign a date between 1901 and 1954 to unseen documents 

2) Train.tsv
A summary of the gold standard data where, for each file id, the corresponding year (YearBasedTask), Class (CoarseTask) and time period (FineTask) are defined.

The test data will be released with the same folder structure, and will include same-genre documents (test data extracted from the same original corpus of the training data) and cross-genre data (test data including a set of De Gasperi’s letters).

The data are licensed under CC BY-NC-ND 4.0.
Do you have doubts or questions? Join our GoogleGroup https://groups.google.com/forum/embed/?place=forum/dadoeval_2020.
